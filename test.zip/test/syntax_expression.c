/**********************************************************************
* Soubor: syntax_expression.c
*
* Popis: implementace syntakticke analyzy vyrazu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Dancak <xdanca01>
* Datum: 18.11.2019
**********************************************************************/
#pragma once
#include "syntax_expression.h"
#define SIZE 7
tSymTabNodePtr symtable;
//precedenční tabulka
Sign tabulka[SIZE][SIZE] = {
          //|+,-  | /,//,*| ( | ) | i | >,<,<=,>= | $ |
            { R   ,  L    , L , R , L ,    R      , R },//|+,-            |
            { R   ,  R    , L , R , L , R         , R },//|/,*            |
            { L   , L     , L , EQ , L , L         , N },//|(              |
            { R   , R     , N , R , N , R         , R },//|)              |
            { R   , R     , N , R , N , R         , R },//|i              |
            { L   , L     , L , R , L , R         , R },//|>,<,<=,>=,==,!=|
            { L   , L     , L , N , L , L         , N }//|$              |
};

//get value from tabulka
Sign WhichValue(Token NaZas, Token prichozi)
{
    T_types prvni = NaZas.typ, druhy = prichozi.typ;
    int Z, V;
    for(int i = 0; i < 2;++i)
    {
        // +, -
        if(prvni == typ_op_plus || prvni == typ_op_minus)
        {
            if(i == 0) Z = 1;
            else V = 1;
        }
        // /,//,*
        else if(prvni == typ_op_mul || prvni == typ_op_div || prvni == typ_op_int_div)
        {
            if(i == 0) Z = 2;
            else V = 2;
        }
        // (
        else if(prvni == typ_left_bracket)
        {
            if(i == 0) Z = 3;
            else V = 3;
        }
        // )
        else if(prvni == typ_right_bracket)
        {
            if(i == 0) Z = 4;
            else V = 4;
        }
        // i
        else if(prvni == typ_double || prvni == typ_integer || prvni == typ_id || prvni == typ_string)
        {
            if(i == 0) Z = 5;
            else V = 5;
        }
        else if(prvni == typ_op_greater || prvni == typ_op_lesser || prvni == typ_op_equal || prvni == typ_op_not_equal || prvni == typ_op_greater_equal || prvni == typ_op_lesser_equal)
        {
            if(i == 0) Z = 6;
            else V = 6;
        }
        // $
        else if(prvni == typ_eol)
        {
            if(i == 0) Z = 7;
            else V = 7;
        }
        //chyba vracime nejakou chybnou hodnotu z tabulky (N)
        else
        {
            Z = 4;
            V = 3;
            break;
        }
        prvni = druhy;
    }
    printf("zas:%d,vstup:%d\n",NaZas.typ,prichozi.typ);
    printf("Z:%d V:%d\n",Z,V);
    return tabulka[Z-1][V-1];
    
}
//E --> (E)
//      E+E
//      E*E
//      E-E
//      E/E
//      i
//      E>=E
Pravidlo StackTermTransfer(int count,StackItem *stack)
{
    // != '<'
    printf("count:%d\n",count);
    for(int i = count - 1;i >= 0;--i)printf("zasobnik:%d\n",stack[i].item_type);
    if(stack[0].item_type != 3) return E_UNKNOWN;
    --count;
    //E --> E
    printf("count je:%d\n",count);
    if(count == 1)
    {
        if(stack[1].item_type == 1)
        {
            //E --> E
            if(stack[1].item.prav == E) return E;
            else if(stack[1].item.prav == E_float) return E_float;
            else if(stack[1].item.prav == E_string) return E_string;
        }
        else if(stack[1].item_type == 2)
        {
            //E --> i
            if(stack[1].item.token.typ == typ_double) return E_float;
            else if (stack[1].item.token.typ == typ_id)
            {
              struct  tSymTabNodeContent content;
                content.typ = 0;
                //TODO
                }
                else if (stack[1].item.token.typ == typ_integer)
                {
                    printf("int\n");
                    return E;
                }
                else if (stack[1].item.token.typ == typ_string) return E_string;
            }
    //E --> (E)
    //      E+E
    //      E*E
    //      E-E
    //      E/E
    //      i
    //      E>=E
    }
    else if(count == 3)
    {
        // E --> E??
        if(stack[1].item_type == 1)
        {
            //E_INT
            if(stack[1].item.prav == E)
            {
                printf("prvni je int\n");
                // E --> E 'operator' ?
                if(stack[2].item_type == 2 && (IsOperator(&stack[2].item.token) == 1))
                {
                    printf("operator");
                    // E --> E 'operator' E
                    if(stack[3].item_type == 1 && stack[3].item.prav == E) return E;
                    // E --> E 'operator' E_float
                    else if(stack[3].item_type == 1 && stack[3].item.prav == E) return E_float;
                    // E --> E 'operator' E_string
                    else if(stack[3].item_type == 1) return E_semantic;
                }
            }
            //E_float
            else if(stack[1].item.prav == E_float)
            {
                // E --> E_float // ERROR
                if(stack[2].item_type == 2 && (IsOperator(&stack[2].item.token) == 1) && stack[2].item.token.typ == typ_op_int_div) return E_UNKNOWN;
                // E --> E_float 'operator' ?
                if(stack[2].item_type == 2 && (IsOperator(&stack[2].item.token) == 1))
                {   
                    // E --> E_float 'operator' E_float|E
                    if(stack[3].item_type == 1 && (stack[3].item.prav == E || stack[3].item.prav == E_float)) return E_float;
                    else if(stack[3].item_type == 1) return E_semantic;
                }
            }
            //E_string
            else if(stack[1].item.prav == E_string)
            {
                // E --> E_string 'operator' ?
                if(stack[2].item_type == 2 && (IsOperator(&stack[2].item.token) == 1))
                {   
                    // E --> E_string 'operator' E_string
                    if(stack[3].item_type == 1 && stack[3].item.prav == E_string) return E_string;
                    // E --> E_string 'operator' E|E_float
                    else if(stack[3].item_type == 1) return E_semantic;
                }   
            }
        }
        // E --> (??
        else if(stack[1].item_type == 2 && stack[1].item.token.typ == typ_left_bracket)
        {
            // E --> (E?
            if(stack[2].item_type == 1)
            {
                if(stack[2].item.prav == E)
                {
                    // E --> (E)
                    if(stack[3].item_type == 2 && stack[3].item.token.typ == typ_right_bracket)
                    {
                        return E;
                    }
                }
                else if(stack[2].item.prav == E_float)
                {   
                    // E --> (E_float)
                    if(stack[3].item_type == 2 && stack[3].item.token.typ == typ_right_bracket)
                    {   
                        return E_float;
                    }   
                }
                else if(stack[2].item.prav == E_string)
                {   
                    // E --> (E_string)
                    if(stack[3].item_type == 2 && stack[3].item.token.typ == typ_right_bracket)
                    {   
                        return E_string;
                    }   
                }
            }
        }
    }
    return E_UNKNOWN;
        
}
// @ret 1 if operator, 2 if value, 3 if $, 4 if :, 5 if (,), 0 else
int IsOperator(Token *token)
{
    if(token->typ == typ_op_plus || token->typ == typ_op_minus || token->typ == typ_op_mul || token->typ == typ_op_div || token->typ == typ_op_int_div || token->typ == typ_op_greater || token->typ == typ_op_lesser || token->typ == typ_op_equal || token->typ == typ_op_not_equal || token->typ == typ_op_greater_equal || token->typ == typ_op_not_equal || token->typ == typ_op_greater_equal || token->typ == typ_op_lesser_equal)
    {
        return 1;
    }
    else if(token->typ == typ_double || token->typ == typ_id || token->typ == typ_integer) return 2;
    else if(token->typ == typ_eol) return 3;
    else if(token->typ == typ_double_dot) return 4;
    else if(token->typ == typ_left_bracket || token->typ == typ_right_bracket) return 5;
    printf("vracim 0\n");
    return 0;
}

int syntax_expression(Token *expression, tSymTabNodePtr tabulka_symbolu)
{
    symtable = tabulka_symbolu;
    Token znak = *expression;
    //
    int dvojtecka = 0;
    StackItem Zitem;
    //$
    Zitem.item.token.typ =  typ_eol;
    //typ token
    Zitem.item_type = 2;
    tStack zasobnik;
    stackInit(&zasobnik);
    //push($)
    stackPush(&zasobnik, Zitem);
    Sign porovnani;
    if(IsOperator(&znak) == 0) return RET_ERR_SYN;
    while(IsOperator(&znak))
    {
        //podivej se co je na vrcholu zasobniku
        stackTop(&zasobnik, &Zitem);
        printf("input token: %d, na zasobniku je:%d \n",znak.typ,Zitem.item.token.typ);
        //token == ':'
        if(IsOperator(&znak) == 4)
        {
            dvojtecka = 1;
            znak.typ = typ_eol;
        }
        //na zasobniku je dollar a na vstupu je dollar
        if(Zitem.item_type == 2 && (IsOperator(&Zitem.item.token) == 3 && IsOperator(&znak) == 3)) break;
        //ziskej sign z tabulky
        porovnani = WhichValue(Zitem.item.token, znak);
        //
        Zitem.item.token = znak;
        Zitem.item_type = 2;
        //chyba syntaxe
        if(porovnani == N)
        {
            printf("chyba syntaxe porovnani == N \n");
            return RET_ERR_SYN;
        }
        //pokud je sign =, tak pushni na zasobnik a precti symbol
        if(porovnani == EQ)
        {
            //push(b)
            stackPush(&zasobnik, Zitem);
        }
        //pokud je sign <, tak zamen a za a< a pushni
        else if(porovnani == L)
        {
            StackItem mensinez;
            mensinez.item_type = 3;
            stackPush(&zasobnik, mensinez);
            stackPush(&zasobnik, Zitem);
        }
        //redukce
        else if(porovnani == R)
        {
            StackItem vystup[SIZE];
            int pocet = stackCount(&zasobnik);
            //pop termu + netermu...
            for(int i = pocet - 1; i >= 0;--i)
            {
                vystup[i] = stackPop(&zasobnik);
            }
            //vytvoreni pravidla pro push na zasobnik
            StackItem dalsi;
            dalsi.item.prav = StackTermTransfer(pocet, &(vystup[0]));
            dalsi.item_type = 1;
            if(dalsi.item.prav == E_UNKNOWN) return RET_ERR_SYN;
            else if(dalsi.item.prav == E_semantic) return RET_ERR_SEM_OTHER;
            //ziskani pravidla z tokenu
            stackPush(&zasobnik, dalsi);
            //musim zachovat prichozi token
            continue;
        }
        int R = get_token(&znak);
        if(R) return R;
    }
    if(dvojtecka) znak.typ = typ_double_dot;
    *expression = znak;
    printf("konec\n");
    return RET_SUCCESS;
}
