/**********************************************************************
* Soubor: string.c
*
* Popis: soubor s funkcemi pro dynamicky alokovany retezec
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Tomas Dvoracek (xdvora3d)
* Datum: 16.10.2019
**********************************************************************/
#include <stdio.h>
#include <string.h>
#include "string.h"
#include "return_codes.h"


#define INIT_LEN 8 // zakladni delka retezce




int D_string_init(D_string * s)
{
    unsigned int init = INIT_LEN;

    s->data = malloc(sizeof(char)*init);
    if(s->data == NULL)
    {
        return D_str_err;
    }

    s->alloc = init;

    D_string_clear(s);


   // printf("joinitalloc %d \n",s->alloc);
   // printf("jolen %d \n",s->len);
    //printf("jost %c \n",s->data[s->len]);

    return D_str_succ;

}

void D_string_clear(D_string * s)
{
    s->len = 0;
    s->data[s->len] = '\0';

}

void D_string_free(D_string * s)
{
    free(s->data);
    free(s);
}

int D_string_add(D_string * s, int znak)
{

    if((s)->len >= (s)->alloc - 2)
    {

        (s)->data = realloc((s)->data, (s)->len + INIT_LEN);
        if((s)->data == NULL)
        {
            D_string_free(s);
            return D_str_err;
        }

        //printf("jo2 \n");
        (s)->alloc = (s)->alloc + INIT_LEN;
    }


   // printf("s->alloc %d \n",(s)->alloc);
    //printf("s->len %d \n",(s)->len);

    (s)->data[(s)->len++] = (char) znak;
    (s)->data[(s)->len] = '\0';

    //printf("s->data %s \n",(s)->data);
   // printf("s->lenafter %d \n",(s)->len);






    return D_str_succ;
}

int D_stringS1_copy_stringS2(D_string *s1 , D_string *s2)
{
    if(s2->len >= s1->alloc) //pokud je delka kopirovaneho retezce delsi nez alokace mista kam ma byt zkopirovan
    {
        s1->data = realloc(s1->data , (s2->len + 1));
        if(s1->data == NULL)
        {
            D_string_free(s1);
            D_string_free(s2);
            return D_str_err;
        }
        s1->alloc = (s2->len + 1);
    }

    strcpy(s1->data, s2->data);
    s1->len = s2->len;

    return D_str_succ;

}

int D_string_cmp_const_str(D_string *s, const char *const_str)
{
    //printf("cmp %s vs %s \n",s->data, const_str);
    //printf("compare %i \n", strcmp(s->data, const_str));
    return strcmp(s->data, const_str);
}






