/**********************************************************************
* Soubor: stack.c
*
* Popis: Zasobnik pro precedencni SA vyrazu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Dancak <xdanca01>
* Datum: 18.11.2019
**********************************************************************/

#include "stack.h"

void stackInit ( tStack* s ) {

	if (s == NULL)return;
	else s->top = -1;

}

int stackEmpty ( const tStack* s ) {

	return (s->top == -1) ? 1 : 0;
}

int stackFull ( const tStack* s ) {

	return (s->top == (STACK_SIZE - 1)) ? 1 : 0;
}

void stackTop ( const tStack* s, StackItem* c ) {

	if (stackEmpty(s) == 1) return;
    for(unsigned i = s->top; i >= 0;--i)
    {
        if(s->arr[i].item_type == 2)
        {
            *c = s->arr[i];
            return;
        }
    }
}


StackItem stackPop ( tStack* s) {

	if (stackEmpty(s) == 1) return;
    --s->top;
    return s->arr[s->top + 1];
}


void stackPush ( tStack* s, StackItem c ) {

	if (stackFull(s) == 1) return;
	else
	{
		++s->top;
		s->arr[s->top] = c;
	}
    if(c.item_type == 1 || c.item_type == 2) return;
    for(unsigned i = s->top; i >= 0 && s->arr[i-1].item_type != 2;--i)
    {
            printf("zasobnik:%d\n",s->arr[i-1].item_type);
            s->arr[i] = s->arr[i-1];
            s->arr[i-1] = c;
    }
}

int stackCount(tStack* s)
{
    int count = 0;
    for(int i = s->top; i >= 0;--i)
    {
        printf("zasobnik:%d\n",s->arr[i].item_type);
        count++;
        if(s->arr[i].item_type == 3) break;
    }
    printf("count:%d\n",count);
    return count;
}

