/**********************************************************************
* Soubor: string.h
*
* Popis: soubor s definicemi funkci pro dynamicky alokovany retezec
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Tomas Dvoracek (xdvora3d)
* Datum: 16.10.2019
**********************************************************************/

#include <stdio.h>
#include <stdlib.h>

#ifndef _DSTRING_H
#define _DSTRING_H

#include <string.h>

#define D_str_err -1
#define D_str_succ 0



typedef struct D_string {
  char *data;
  unsigned int len;
  unsigned int alloc;
}D_string;

extern struct D_string str;


/**
 * Inicializace dynamicky alokovaneho retezce.
 *
 * @param s Ukazatel na dynamicky retezec.
 * @return 0(D_str_succ) pokud se inicializace povedla, jinak -1(D_str_err).
 */

int D_string_init(D_string * s);

/**
 * Vynulovani dynamicky alokovaneho retezce.
 *
 * @param s Ukazatel na dynamicky retezec.
 */


void D_string_clear(D_string * s);

/**
 * Uvolneni pameti dynamicky alokovaneho retezce.
 *
 * @param s Ukazatel na dynamicky retezec.
 */


void D_string_free(D_string * s);

/**
 * Pridani jednoho znaku do dynamicky alokovaneho retezce.
 *
 * @param s Ukazatel na dynamicky retezec.
 * @param znak Znak, ktery ma byt pridan.
 * @return 0(D_str_succ) Pokud se pridani podarilo, jinak -1 (D_str_err).
 */

int D_string_add(D_string * s, int znak);

/**
 * Zkopiruje retezec s2 do dynamicky alokovaneho retezce.
 *
 * @param s Ukazatel na dynamicky retezec.
 * @param s2 Ukazatel na retezec, ktery ma byt zkopirovan.
 */

int D_stringS1_copy_stringS2(D_string *s1 , D_string *s2);

/**
 * Porovna retezec s2 s dynamicky alokovanym retezcem.
 *
 * @param s Ukazatel na dynamicky retezec.
 * @param const_str Ukazatel na retezec, ktery ma byt porovnavan.
 *
 * @return 0 pokud se retezce rovnaji, jinak cislo > || < 0.
 */

int D_string_cmp_const_str(D_string *s, const char *const_str);


#endif