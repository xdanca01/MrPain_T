
/**********************************************************************
* Soubor: symtable.h
*
* Popis: Hlavickovy soubor k tabulce symbolu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Kovar (xkovar82)
* Datum: 31.10.2019
**********************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>

#include "string.h" // dynamicky string

#define TRUE 1
#define FALSE 0

#define VAR 0
#define FUNC 1

#ifndef _SYMTABLE_H
#define _SYMTABLE_H

enum datatype{NOT_ASSIGNED, INT, DOUBLE, STRING, NONE}; 

// struktura s konkretnim obsahem uzlu
typedef struct tSymTabNodeContent {
	int typ;      	// promenna / funkce
	int defined;  	// byla definovana?
	int datovy_typ;
	int pocet_parametru; // pocet parametru u funkce

} *tSymTabNodeContentPtr;

/* uzel stromu / tabulky symbolu */

typedef struct tSymTabNode {
	D_string * key;                // klic
	tSymTabNodeContentPtr obsah; // ukazatel na strukturu s obsahem uzlu
	struct tSymTabNode * LPtr;     // uk. na levy podstrom
	struct tSymTabNode * RPtr;     // uk. na pravy podstrom
} *tSymTabNodePtr;

// Inicializace binarniho stromu / tabulky symbolu
void tSymTabInit(tSymTabNodePtr *);

// Hledani uzlu
int tSymTabSearch(tSymTabNodePtr *, D_string * K, tSymTabNodeContentPtr);

// Vkladani do tabulky
void tSymTabInsert(tSymTabNodePtr *, D_string *, struct tSymTabNodeContent content);

// Vyhledani nejpravejsiho prvku
void ReplaceByRightmost(tSymTabNodePtr PtrReplaced, tSymTabNodePtr *RootPtr);

// Smazani prvku z tabulky
void tSymTabDelete(tSymTabNodePtr *, D_string *);

// Zruseni cele tabulky symbolu 
void tSymTabDispose(tSymTabNodePtr *);

#endif