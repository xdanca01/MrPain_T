#define MAIN
#include "scannerV2.h"
#include "syntax_expression.h"
#include "stack.h"
#include "return_codes.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>

int main()
{
    Token token;
    tSymTabNodePtr tabulka = NULL;
    set_src_file(stdin);
    int value = get_token(&token);
    if(value) return value;
    printf("prvni token: %d \n",token.typ);
    return syntax_expression(&token,tabulka); 
}
