/**********************************************************************
* Soubor: stack.h
*
* Popis: Zasobnik pro precedencni SA vyrazu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Dancak <xdanca01>
* Datum: 18.11.2019
**********************************************************************/


#include "scannerV2.h"
#ifndef STACK
#define STACK
#define STACK_SIZE 64

typedef enum{
    E, // prav int
    E_string, // string
    E_float, //float
    E_UNKNOWN, // ?
    E_semantic, //semanticka chyba
}Pravidlo;

typedef enum{
    R,//>
    L,//<
    EQ,//=
    N,//ERROR
    X,//nothing
}Sign;

typedef union{
    Pravidlo prav;
    Token token;
}Item;

typedef struct{
    Item item;
    //1 - pravidlo, 2 - token, 3 - <;
    int item_type;
}StackItem;

                             /* ADT zásobník implementovaný ve statickém poli */
typedef struct {
	StackItem arr[STACK_SIZE];                             /* pole pro uložení hodnot */
	int top;                                /* index prvku na vrcholu zásobníku */
} tStack;

                                  /* Hlavičky funkcí pro práci se zásobníkem. */
void stackInit ( tStack* s );
int stackEmpty ( const tStack* s );
int stackFull ( const tStack* s );
void stackTop ( const tStack* s, StackItem* c );
StackItem stackPop ( tStack* s );
void stackPush ( tStack* s, StackItem c );
//pocet pop do(vcetne) prvniho <
int stackCount(tStack* s);
#endif
