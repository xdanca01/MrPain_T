/**********************************************************************
* Soubor: syntax_expression.h
*
* Popis: implementace syntakticke analyzy vyrazu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Dancak <xdanca01>
* Datum: 18.11.2019
**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>
#include "scannerV2.h"
#include "symtable.h"
#include "stack.h"
#include <ctype.h>

//get value from tabulka
Sign WhichValue(Token NaZas, Token prichozi);

Pravidlo TokenTransfer(Token token);

// @ret 1 if operator, 2 if value, 3 if $, 0 else
int IsOperator(Token *token);

int syntax_expression(Token *expression, tSymTabNodePtr tabulka_symbolu);

