/**********************************************************************
* Soubor: return_codes.h
*
* Popis: Hlavickovy soubor s definicemi vsech navratovych kodu
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Kovar (xkovar82)
* Datum: 14.10.2019
**********************************************************************/

#ifndef _RETURN_CODES_H
#define _RETURN_CODES_H

#define RET_SUCCESS           0 // beh bez chyb
#define RET_ERR_LEX           1 // chyba lexikalni analyzy
#define RET_ERR_SYN           2 // chyba syntakticke analyzy
#define RET_ERR_SEM_DEF       3 // semanticka chyba - nedefinovana fce/promenna pokus o redefinici
#define RET_ERR_SEM_COMP      4 // sem. chyba typove kompatibility v artimet., retez. a relacnich vyrazech
#define RET_ERR_SEM_ARG_CNT   5 // sem. chyba - spatny pocet parametru u volani fce
#define RET_ERR_SEM_OTHER     6 // ostatni semanticke chyby
#define RET_ERR_DIV_BY_ZERO   9 // behova chyba deleni nulou
#define RET_ERR_INTERNAL      99 // interni chyba prekladace (alokace pameti...)

#endif
