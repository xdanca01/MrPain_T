/**********************************************************************
* Soubor: scanner.c
*
* Popis: implementace lexikalni analyzy
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Tomas Dvoracek(xdvora3d)
* Datum: 18.10.2019
**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>

#include "scannerV2.h"


#include <ctype.h>





//D_str * d_string; // inicializace dyn. retezce


struct Indent_stack i_stack;
struct D_string string ;

FILE * input_file = NULL;

bool novy_radek = true; // priznak jestli je zacatek noveho radku
bool gen_ENT = true;


const char *KeyWord_arr[] =
{
    // vycet klicovych slov
    [kw_some_keyword] = "some_keyword",
    [kw_def] = "def",
    [kw_else] = "else",
    [kw_if] = "if",
    [kw_none] = "None",
    [kw_pass] = "pass",
    [kw_return] = "return",
    [kw_while] = "while",

    // vycet vestavenych funkci
    [kw_inputs] = "inputs",
    [kw_inputi] = "inputi",
    [kw_inputf] = "inputf",
    [kw_print] = "print",
    [kw_len] = "len",
    [kw_substr] = "substr",
    [kw_ord] = "ord",
    [kw_chr] = "chr"

};

typedef enum
{
    state_start,
    state_greater,
    state_lesser,
    state_eol,
    state_after_eol,
    state_comentary,
    state_block_comentary1,
    state_block_comentary2,
    state_block_comentary3,
    state_block_comentary_leave1,
    state_block_comentary_leave2,
    state_identifier,
    state_digit,
    state_digit_exponent,
    state_exponent_sign,
    state_exponent_part,
    state_digit_dot,
    state_digit_dot_digit,
    state_digit_dot_digit_exponent,
    state_string,
    state_string_escape,
    state_string_hex_escape,
    state_string_hex_escape1,
    state_exlamation_mark,
    state_div,




}S_state;



bool return_identifier(D_string * strings, Token * token)
{
    unsigned const int key_w_count = 15; // celkovy pocet klic. slov

    for(unsigned int i = 0; i < key_w_count; i++)
    {
        if((D_string_cmp_const_str(strings, KeyWord_arr[i+1])) == 0)
        {
            token->str = strings;
            return true; // je klic slovo
        }
    }

    token->str = strings;
    return false; // neni klic slovo
}

int return_int_number(D_string * strings, Token * token)
{
    int number;
    char * end;

    number = (int) strtol(strings->data, &end, 10);
    if(end == strings->data || errno == ERANGE)
    {
        return RET_ERR_LEX;
    }


    token->typ = typ_integer;
    token->str = strings;

    return OK;
}

int return_double_number(D_string * strings, Token * token)
{
    double number;
    char * end;

    number = strtod(strings->data, &end);
    if(end == strings->data || errno == ERANGE)
    {
        return RET_ERR_LEX;
    }

    token->str = strings;
    token->typ = typ_double;

    return OK;
}

char return_char_from_hex(char * hexstring)
{
    int number;
    char ascii;
    char * end;

    number = (int) strtol(hexstring, &end, 16);
    ascii = (char) number;

    return ascii;
}

void set_src_file(FILE * input_f)
{
    input_file = input_f;
}


int indent_stack_init(Indent_stack * i_stack)
{
    i_stack->stack_arr = malloc(sizeof(int)* init_size );
    if(i_stack->stack_arr == NULL)
    {
        return RET_ERR_INTERNAL;
    }


    i_stack->alloc_size = init_size;

    i_stack->top = 0;

    i_stack->stack_arr[i_stack->top] = 0;
    return 0;
}


void indent_stack_free(Indent_stack * i_stack)
{
    free(i_stack);
}


int work_with_indent_stack(Indent_stack * i_stack, Token * token, int pocet_odsazeni) // zasobnik odsazeni
{


    if(i_stack->top == i_stack->alloc_size) // pokud kapacita zasobniku nedostacuje tak se zasobnik rozsiri
    {
        i_stack->stack_arr = realloc(i_stack->stack_arr, sizeof(unsigned int)*init_size);
        if(i_stack->stack_arr == NULL)
        {
            return RET_ERR_INTERNAL;
        }
    }

    if(pocet_odsazeni > i_stack->stack_arr[i_stack->top]) // pokud je pocet odsazeni vetsi nez hodnota na vrcholu zasobniku tak se hodnota odsazeni da na vrchol zasobniku a generuje se INDENT
    {
        i_stack->top++;
        i_stack->stack_arr[i_stack->top] = pocet_odsazeni;
        token->typ = INDENT;
        novy_radek = false;
        gen_ENT = true;
    }

    else if(pocet_odsazeni < i_stack->stack_arr[i_stack->top]) // pokud je pocet odsazeni mensi tak se odebira tak dlouho dekud se nenajde stejna hodnota nebo dokud neni prazdny zasobnik a generuje se DEDENT
    {
        novy_radek = true;
        gen_ENT = true;
        if((i_stack->stack_arr[i_stack->top] != pocet_odsazeni) && (i_stack->top != 0))
        {
            i_stack->top--;
            token->typ = DEDENT;
        }

        for(int i = i_stack->top; true ; i--) // pokud se stejna hodnota nenasla tak lexikalni error
        {
            if(i_stack->stack_arr[i] == pocet_odsazeni)
            {
                break;
            }
            else if(i == 0)
            {
                return RET_ERR_LEX;
            }
        }

        fseek(input_file, -1*pocet_odsazeni, SEEK_CUR); // vygeneruje se DEDENT, snizi se hodnota vrcholu o jeden a ukazatel v souboru se posune zpìt o poèet odsazení urceneho v get_token
    }
    else
    {
        novy_radek = false;
        gen_ENT = false;
    }

    return 0;
}




int get_token(Token * token)
{


    if(input_file == NULL)
    {

        return RET_ERR_INTERNAL;
    }



    bool nula_na_zacatku = false; // priznak jestli je zpracovavane des. cislo
    char hexstring[3];
    hexstring[2] = '\0';
    int actual_char;
    int pocet_odsazeni = 0;

    S_state state = state_start;

    while(true)
    {
        actual_char = getc(input_file);

        if(novy_radek == true)
        {
            state = state_after_eol;
        }

        switch(state)
        {
        case(state_start):
            {
                pocet_odsazeni = 0;

                if(actual_char == '\n' )
                {
                    state = state_eol;
                    fseek(input_file, -1, SEEK_CUR);
                }

                else if(actual_char == '#')
                {
                    state = state_comentary;
                }

                else if(actual_char == EOF)
                {
                    token->typ = typ_eof;
                    return OK;
                }

                else if(actual_char == ' ')
                {
                    break;
                }

                else if(isspace(actual_char) != 0)
                {
                    state = state_start;
                    fseek(input_file, -1, SEEK_CUR);
                }

                else if(actual_char == '>' )
                {
                    state = state_greater;
                }

                else if(actual_char == '<' )
                {
                    state = state_lesser;
                }

                else if(actual_char == '"' )
                {
                    state = state_block_comentary1;
                }

                else if(isalpha(actual_char) != 0 || actual_char == '_' )
                {

                    D_string_init(&string);
                    state = state_identifier;
                    fseek(input_file, -1, SEEK_CUR);
                }

                else if(isdigit(actual_char) != 0)
                {
                    if(actual_char == '0')
                    {
                        if(getc(input_file) == '0')
                        {
                            return RET_ERR_LEX;
                        }
                        fseek(input_file, -1, SEEK_CUR);
                    }

                    D_string_init(&string);
                    state = state_digit;
                    fseek(input_file, -1, SEEK_CUR);
                }

                else if(actual_char == '\'')
                {
                    D_string_init(&string);
                    state = state_string;
                }

                else if(actual_char == '!')
                {
                    state = state_exlamation_mark;
                }

                else if(actual_char == '/')
                {
                    state = state_div;

                }

                else if(actual_char == '+')
                {
                    token->typ = typ_op_plus;
                    return OK;
                }

                else if(actual_char == '-')
                {
                    token->typ = typ_op_minus;
                    return OK;
                }

                else if(actual_char == '*')
                {
                    token->typ = typ_op_mul;
                    return OK;
                }

                else if(actual_char == '=')
                {
                    token->typ = typ_op_assign;
                    return OK;
                }

                else if(actual_char == ',')
                {
                    token->typ = typ_comma;
                    return OK;
                }
                else if(actual_char == ':')
                {
                    token->typ = typ_double_dot;
                    return OK;
                }

                else if(actual_char == ')')
                {
                    token->typ = typ_right_bracket;
                    return OK;
                }

                else if(actual_char == '(')
                {
                    token->typ = typ_left_bracket;
                    return OK;
                }

                else
                {
                    return RET_ERR_LEX;
                }

                break;
            }

            case (state_eol):
            {
                novy_radek = true;
                state = state_after_eol;
                token->typ = typ_eol;
                return OK;
            }
            case (state_after_eol):
            {
                if(actual_char == EOF)
                {
                    token->typ = typ_eof;
                    return OK;
                }

                while(actual_char == ' ')
                {
                    pocet_odsazeni++;
                    actual_char = getc(input_file);
                }

                if(isspace(actual_char) != 0)
                {
                    pocet_odsazeni = 0;
                    break;
                }

                else if(actual_char == '#') // zjisteni jestli dalsi znak co neni mezera neni zacatek radkoveho komentare nebo jiny prazdny znak (\n, \t)
                {
                    while(actual_char != '\n' && actual_char != EOF)
                    {
                        actual_char = getc(input_file);
                    }

                    if(actual_char == EOF) // komentar byl posledni v celem souboru
                    {
                        token->typ = typ_eof;
                        return OK;
                    }

                    pocet_odsazeni = 0;
                    break;


                }
                else
                {
                    fseek(input_file, -1, SEEK_CUR);

                    int ret_code = work_with_indent_stack(&i_stack, token, pocet_odsazeni);

                    if(novy_radek == false)
                    {
                        state = state_start;
                        if(gen_ENT == false)
                        {
                            break;
                        }
                    }

                    if(ret_code == RET_ERR_INTERNAL)
                    {
                        return RET_ERR_INTERNAL;
                    }
                    else if(ret_code == RET_ERR_LEX)
                    {
                        return RET_ERR_LEX;
                    }

                    if(token->typ == INDENT || token->typ == DEDENT) // pokud se podarilo vygenerovat token tak OK (je mozne ze pocet odsazeni se rovnal vrcholu zasobniku - to by se nic negenerovalo)
                    {
                        return OK;
                    }
                }



                break;
            }

            case (state_comentary):
            {
                if(actual_char == '\n')
                {
                    fseek(input_file, -1, SEEK_CUR);
                    state = state_start;
                }
                else if(actual_char == EOF)
                {
                    token->typ = typ_eof;
                    return OK;
                }

                break;
            }


            case (state_block_comentary1):
            {
                if(actual_char == '"')
                {
                    state = state_block_comentary2;
                }
                else
                {
                    return RET_ERR_LEX;
                }

                break;
            }

            case (state_block_comentary2):
            {
                if(actual_char == '"')
                {
                    D_string_init(&string);
                    state = state_block_comentary3;

                }
                else
                {
                    return RET_ERR_LEX;
                }

                break;
            }

            case (state_block_comentary3):
            {

                if(actual_char == '\\')
                {
                    actual_char = getc(input_file);
                    if(actual_char == '"')
                    {
                        if(D_string_add(&string, actual_char) == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }
                    }
                    else
                    {
                        if(D_string_add(&string, '\\') == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }

                        fseek(input_file, -1, SEEK_CUR);
                    }
                }
                else if (actual_char == '"' )
                {
                    state = state_block_comentary_leave1;
                }
                else if (actual_char == EOF)
                {
                    return RET_ERR_LEX;
                }
                else
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }


                break;
            }

            case (state_block_comentary_leave1):
            {
                if(actual_char == '\\')
                {
                    actual_char = getc(input_file);
                    if(actual_char == '"')
                    {
                        if(D_string_add(&string, actual_char) == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }
                    }
                    else
                    {
                        if(D_string_add(&string, '\\') == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }

                        fseek(input_file, -1, SEEK_CUR);
                    }

                    state = state_block_comentary3;
                }
                else if(actual_char == '"')
                {
                    state = state_block_comentary_leave2;
                }
                else if(actual_char == EOF)
                {
                    return RET_ERR_LEX;
                }
                else
                {
                    fseek(input_file, -1, SEEK_CUR);
                    state = state_block_comentary3;
                }

                break;
            }

            case (state_block_comentary_leave2):
            {
                if(actual_char == '\\')
                {
                    actual_char = getc(input_file);
                    if(actual_char == '"')
                    {
                        if(D_string_add(&string, actual_char) == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }
                    }
                    else
                    {
                        if(D_string_add(&string, '\\') == D_str_err)
                        {
                            return RET_ERR_INTERNAL;
                        }

                        fseek(input_file, -1, SEEK_CUR);
                    }

                    state = state_block_comentary3;
                }
                else if(actual_char == '"')
                {
                    token->typ = typ_block_comment;
                    token->str = &string;

                    return OK;
                }
                else if(actual_char == EOF)
                {
                    return RET_ERR_LEX;
                }
                else
                {
                    fseek(input_file, -1, SEEK_CUR);
                    state = state_block_comentary3;
                }

                break;
            }

            case (state_greater):
            {
                if(actual_char == '=')
                {
                    token->typ = typ_op_greater_equal;
                }
                else
                {
                    token->typ = typ_op_greater;
                    fseek(input_file, -1, SEEK_CUR);
                }

                return OK;
            }

            case (state_lesser):
            {
                if(actual_char == '=')
                {
                    token->typ = typ_op_lesser_equal;
                }
                else
                {
                    token->typ = typ_op_lesser;
                    fseek(input_file, -1, SEEK_CUR);
                }

                return OK;
            }

            case (state_exlamation_mark):
            {
                if(actual_char == '=')
                {
                    token->typ = typ_op_not_equal;
                }
                else
                {
                    return RET_ERR_LEX;
                }

                return OK;
            }
            case (state_div):
            {
                if(actual_char == '/')
                {
                    token->typ = typ_op_int_div;
                }
                else
                {
                    token->typ = typ_op_div;
                }

                return OK;
            }

            case (state_identifier):
            {

                if(actual_char == '_' || isalnum(actual_char) != 0)
                {

                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else
                {
                    if(actual_char != EOF)
                    {
                        fseek(input_file, -1, SEEK_CUR);
                    }

                    if(return_identifier(&string, token) == true)
                    {
                        token->typ = typ_keyword;
                    }
                    else
                    {
                        token->typ = typ_id;
                    }

                    return OK;
                }

                break;
            }

            case (state_digit):
            {
                if(isdigit(actual_char) != 0 )
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == 'e' || actual_char == 'E')
                {

                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_digit_exponent;
                }
                else if(actual_char == '.')
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                    state = state_digit_dot;
                }
                else
                {
                    if(actual_char != EOF)
                    {
                        fseek(input_file, -1, SEEK_CUR);
                    }

                    return return_int_number(&string, token);
                }

                break;
            }

            case (state_digit_exponent):
            case (state_digit_dot_digit_exponent):
            {
                if(actual_char == '+' || actual_char == '-')
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_exponent_sign;
                }
                else if(isdigit(actual_char) != 0)
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_exponent_part;
                }

                else
                {
                    return RET_ERR_LEX;
                }

                break;
            }

            case (state_exponent_sign):
            {
                if(isdigit(actual_char) != 0)
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_exponent_part;
                }
                else
                {
                    return RET_ERR_INTERNAL;
                }

                break;
            }

            case (state_exponent_part):
            {
                if(isdigit(actual_char) != 0)
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else
                {
                    if(actual_char != EOF)
                    {
                        fseek(input_file, -1, SEEK_CUR);
                    }

                    return return_double_number(&string, token);
                }

                break;
            }

            case(state_digit_dot):
            {
                if(isdigit(actual_char) != 0)
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_digit_dot_digit;
                }
                else
                {
                    return RET_ERR_LEX;
                }

                break;

            }

            case(state_digit_dot_digit):
            {
                if(isdigit(actual_char) != 0)
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }

                else if(actual_char == 'e' || actual_char == 'E')
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                    state = state_digit_dot_digit_exponent;
                }
                else
                {
                    return return_double_number(&string, token);
                }


                break;
            }

            case (state_string):
            {
                if(actual_char > 31 && actual_char != '\\' && actual_char != '\'')
                {
                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == '\'')
                {

                    if(D_stringS1_copy_stringS2(token->str, &string) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }


                    token->typ = typ_string;

                    return OK;

                }
                else if(actual_char == '\\')
                {

                    state = state_string_escape;
                }
                else
                {
                    return RET_ERR_LEX;
                }

                break;
            }
            case (state_string_escape):
            {
                if(actual_char == '"')
                {
                    if(D_string_add(&string, '"') == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == '\'')
                {
                    if(D_string_add(&string, '\'') == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == 'n')
                {
                    if(D_string_add(&string, '\n') == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == 't')
                {
                    if(D_string_add(&string, '\t') == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == '\\') // pokud bude v stringu "\\"
                {
                    if(D_string_add(&string, '\\') == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                }
                else if(actual_char == 'x')
                {
                    state = state_string_hex_escape;
                    break;
                }
                else
                {
                    if(D_string_add(&string, '\\') == D_str_err) // napr pokud bude \a , \b
                    {
                        return RET_ERR_INTERNAL;
                    }

                    if(D_string_add(&string, actual_char) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }

                }

                state = state_string;

                break;
            }
            case (state_string_hex_escape):
            {
                if(isxdigit(actual_char) != 0)
                {
                    hexstring[0] = actual_char;
                    state = state_string_hex_escape1;
                }
                else
                {
                    return RET_ERR_LEX;
                }
                break;
            }

            case (state_string_hex_escape1):
            {
                if(isxdigit(actual_char) != 0)
                {
                    hexstring[1] = actual_char;

                    if(D_string_add(&string, return_char_from_hex(hexstring)) == D_str_err)
                    {
                        return RET_ERR_INTERNAL;
                    }
                    state = state_string;
                }
                else
                {
                    return RET_ERR_LEX;
                }
                break;
            }
        }
    }
}



