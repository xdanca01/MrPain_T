
/**********************************************************************
* Soubor: scanner.h
*
* Popis: soubor s definicemi funkci pro scanner a s definicemi datovych struktur v nem pouzivanych
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Tomas Dvoracek (xdvora3d)
* Datum: 18.10.2019
**********************************************************************/
#pragma once
#include <stdio.h>
#include <stdbool.h>
#include "string.h"
#include "return_codes.h"

#define init_size 20 // inicializacni hodnota zasobniku odsazeni
#define OK 0 // pokud se podarilo vygenerovat token tak se da return OK


typedef enum
{
    kw_some_keyword,  // 0
    kw_def,  // 1
    kw_else,  // 2
    kw_if,
    kw_none, // 4
    kw_pass,
    kw_return, // 6
    kw_while,

    kw_inputs, // 8
    kw_inputi,
    kw_inputf,  // 10
    kw_print,
    kw_len,  // 12
    kw_substr,
    kw_ord,  // 14
    kw_chr,

}Keyword;


typedef enum
{
    typ_double, // 0
    typ_eol,
    typ_eof,  // 2
    typ_id,
    typ_integer, // 4
    typ_keyword,
    typ_block_comment, // 6
    typ_comma,
    typ_double_dot, // 8
    typ_string,
    typ_op_plus, // 10
    typ_op_minus,
    typ_op_mul,
    typ_op_div,
    typ_op_int_div,
    typ_op_assign,
    typ_op_greater,
    typ_op_lesser,
    typ_op_equal,
    typ_op_not_equal,
    typ_op_greater_equal,
    typ_op_lesser_equal,
    typ_left_bracket,
    typ_right_bracket,
    INDENT,
    DEDENT,




}T_types;








typedef struct Token
{
    T_types typ;

    D_string * str;

}Token;

typedef struct Indent_stack
{
    int *stack_arr;
    unsigned int alloc_size;
    unsigned int top; //vrchol zasobniku

}Indent_stack;

extern struct Indent_stack i_stack;




bool return_identifier(D_string * strings, Token * token);

int return_int_number(D_string * strings, Token * token);

int return_double_number(D_string * strings, Token * token);

char return_char_from_hex(char * hexstring);

int indent_stack_init(Indent_stack * i_stack);

void indent_stack_free(Indent_stack * i_stack);

int work_with_indent_stack(Indent_stack * i_stack, Token * token, int pocet_odsazeni);

int get_token(Token * token);

void set_src_file(FILE * input_f);







