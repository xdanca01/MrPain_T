/**********************************************************************
* Soubor: symtable.c
*
* Popis: Implementace tabulky symbolu pomoci BST
*        Prevzaty kod ze predmetu IAL
*
* Projekt: Implementace prekladace imperativniho jazyka IFJ19
*
* Autori: Petr Kovar (xkovar82)
* Datum: 31.10.2019
**********************************************************************/

#include "symtable.h"
#include <string.h>

// ----- Operace nad binarnim vyhledavacim stromem / tabulkou symbolu -----

void tSymTabInit(tSymTabNodePtr *RootPtr) {
	*RootPtr = NULL;
}

int tSymTabSearch(tSymTabNodePtr* RootPtr, D_string * K, tSymTabNodeContentPtr content) {

	if ((*RootPtr) == NULL) {
		return FALSE;
	}	else {
		if (strcmp(K->data, (*RootPtr)->key->data) == 0) { // Klice se rovnaji, vrati se content
			content = (*RootPtr)->obsah;
			return TRUE;
		} else {
			if (strcmp(K->data, (*RootPtr)->key->data) < 0) { // hledani v levem podstromu
				return tSymTabSearch(&(*RootPtr)->LPtr, K, content);
			} else { // hledani v pravem podstromu
				return tSymTabSearch(&(*RootPtr)->RPtr, K, content);
			}
		}
	}

}

void tSymTabInsert(tSymTabNodePtr* RootPtr, D_string * K, struct tSymTabNodeContent content) {

	if (*RootPtr == NULL) { // vytvor uzel
		*RootPtr = malloc(sizeof(struct tSymTabNode));
		if (*RootPtr != NULL) {

      if ((*RootPtr)->key == NULL) { // alokace struct dyn. stringu pro klic
        (*RootPtr)->key = malloc(sizeof(struct D_string));
        if ((*RootPtr)->key != NULL) {

          D_string_init( (*RootPtr)->key );
        
        }

        D_stringS1_copy_stringS2((*RootPtr)->key, K);

        if ((*RootPtr)->obsah == NULL) { // alokace obsahu
          (*RootPtr)->obsah = malloc(sizeof(struct tSymTabNodeContent));
          if ((*RootPtr)->obsah != NULL) {
            (*RootPtr)->obsah->typ = content.typ;
						(*RootPtr)->obsah->defined = content.defined;
						(*RootPtr)->obsah->datovy_typ = content.datovy_typ;
						(*RootPtr)->obsah->pocet_parametru = content.pocet_parametru;
          }
        }
      }

			(*RootPtr)->LPtr = NULL;
			(*RootPtr)->RPtr = NULL;
		}
	} else {
		if (strcmp(K->data, (*RootPtr)->key->data) < 0) { // zapis vlevo
			tSymTabInsert(&(*RootPtr)->LPtr, K, content);
		} else { 
			if (strcmp(K->data, (*RootPtr)->key->data) > 0) { // vpravo
				tSymTabInsert(&(*RootPtr)->RPtr, K, content);
			} else { // prepis starych dat
        (*RootPtr)->obsah->typ = content.typ;
			}
		}
	}

}

void ReplaceByRightmost(tSymTabNodePtr PtrReplaced, tSymTabNodePtr *RootPtr) {

	tSymTabNodePtr nodePtr = NULL;
	
	if (*RootPtr != NULL) {
		if ((*RootPtr)->RPtr != NULL) {
			ReplaceByRightmost(PtrReplaced, &(*RootPtr)->RPtr);
		} else {
			PtrReplaced->obsah = (*RootPtr)->obsah; // Zkopirovani obsahu a klice
			PtrReplaced->key = (*RootPtr)->key;
			nodePtr = (*RootPtr); // Ulozeni puvodniho ukazatele
			*RootPtr = (*RootPtr)->LPtr; // Pripojeni leveho podstromu
			free(nodePtr);
		}
	}

}

void tSymTabDelete(tSymTabNodePtr *RootPtr, D_string * K) {
	
	tSymTabNodePtr nodePtr = NULL;

	if (*RootPtr != NULL) {
		if (strcmp(K->data, (*RootPtr)->key->data) > 0) {
			tSymTabDelete(&(*RootPtr)->RPtr, K);
		} else if(strcmp(K->data, (*RootPtr)->key->data) < 0) { // root key > K
			tSymTabDelete(&(*RootPtr)->LPtr, K);
		} else {
			nodePtr = (*RootPtr);
			if ((*RootPtr)->RPtr == NULL) {
				(*RootPtr) = nodePtr->LPtr;
				D_string_free(nodePtr->key);
				free(nodePtr->obsah);
				free(nodePtr);
			} else if ((*RootPtr)->LPtr == NULL) {
				(*RootPtr) = nodePtr->RPtr;
				D_string_free(nodePtr->key);
				free(nodePtr->obsah);
				free(nodePtr);
			} else {
				ReplaceByRightmost(*RootPtr, &(*RootPtr)->LPtr);
			}
		}
	}

} 

void tSymTabDispose(tSymTabNodePtr *RootPtr) {
	
	while (*RootPtr != NULL) {
    D_string_free((*RootPtr)->key);
    free((*RootPtr)->obsah);

		tSymTabDispose(&(*RootPtr)->LPtr); // Zruseni leveho podstromu
		tSymTabDispose(&(*RootPtr)->RPtr); // Zruseni praveho podstromu
		free(*RootPtr); // uvolnime pamet
		*RootPtr = NULL;
	}

}


// ----- Operace nad tabulkou symbolu -----

